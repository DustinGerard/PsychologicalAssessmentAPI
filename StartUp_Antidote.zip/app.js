function login() {
  console.log("hello");
    var loCId = $('#username').val();
  var locTitle = $('#password').val();
  $.ajax({
   url: 'http://127.0.0.1:5000/login/'+loCId+'/'+locTitle,
   data:$('form').serialize(),
    type: "POST",
      success: function(resp) {
       if(resp.status==='ok'){
            window.location.replace('Antidote.html');
       }else if(resp.status==='error'){
            window.location.replace('Antidote(LogIn).html');
       }setRequestHeader("Authorization",
                        "Basic " + btoa("ako:akolagini"));
        }
  });
}/**
 * Created by Dustin Gerard on 5/14/2017.
 */


      },
      error: function(resp) {
        window.location.replace('/texs/404.html');
      },
      beforeSend: function (xhrObj){
              xhrObj.