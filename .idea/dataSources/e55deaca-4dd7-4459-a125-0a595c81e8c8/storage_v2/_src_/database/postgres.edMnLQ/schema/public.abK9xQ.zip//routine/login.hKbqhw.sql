CREATE FUNCTION login(par_user_name text, par_user_password text)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
    loc_user_name text;
    loc_user_password text;
    loc_res text;
  begin
     select into loc_user_name user_name, loc_user_password user_password
     from "Accounts" where user_name = par_user_name and user_password = par_user_password;

     if loc_user_name isnull AND loc_user_password isnull then
       loc_res = 'Error';
     else
       loc_res = 'ok';
     end if;
     return loc_res;
  end;
$$;

