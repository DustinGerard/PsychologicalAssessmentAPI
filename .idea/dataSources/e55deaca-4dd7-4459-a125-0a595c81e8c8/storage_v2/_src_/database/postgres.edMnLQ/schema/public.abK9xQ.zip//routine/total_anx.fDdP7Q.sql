CREATE FUNCTION total_anx(par_value text)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

  begin
    if par_value NOTNULL THEN

      update results set totalscore =  (select sum(anxiety.points) as "total score" from anxiety) where category = 'Anxiety';
      update results set diagnosis='You have no Anxiety.' where totalscore BETWEEN 0 and 4 and category = 'Anxiety';
      update results set diagnosis='You have Mild Anxiety.' where totalscore BETWEEN 5 and 9 and category = 'Anxiety';
      update results set diagnosis='You have Moderate Anxiety.' where totalscore BETWEEN 10 and 14 and category = 'Anxiety';
      update results set diagnosis='You have Severe Anxiety.' where totalscore BETWEEN 15 and 21 and category = 'Anxiety';
    loc_res = 'ok';
     else
       loc_res = 'Error';
     end if;
     return loc_res;
      end;
$$;

