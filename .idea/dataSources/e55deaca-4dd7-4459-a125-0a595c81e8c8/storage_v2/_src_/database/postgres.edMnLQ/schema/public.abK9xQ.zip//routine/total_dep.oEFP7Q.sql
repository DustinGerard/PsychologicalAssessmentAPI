CREATE FUNCTION total_dep(par_value text)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;
  begin
     if par_value NOTNULL then
        /*select sum(anxiety.points) as "total score" from anxiety;*/
        update results set totalscore =  (select sum(depression.points) as "total score" from depression) where category = 'Depression';
        update results set diagnosis='You have no Depression.' where totalscore BETWEEN 0 and 4 and category = 'Depression';
        update results set diagnosis='You have Mild Depression.' where totalscore BETWEEN 5 and 9 and category = 'Depression';
        update results set diagnosis='You have Moderate Depression.' where totalscore BETWEEN 10 and 14 and category = 'Depression';
        update results set diagnosis='You have Moderately Severe Depression.' where totalscore BETWEEN 15 and 19 and category = 'Depression';
        update results set diagnosis='You have Severe Depression.' where totalscore BETWEEN 20 and 27 and category = 'Depression';
        loc_res = 'ok';
     else
       loc_res = 'Error';
     end if;
     return loc_res;
      end;
$$;

