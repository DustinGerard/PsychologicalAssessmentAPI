CREATE FUNCTION first_name(par_value text)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;
  begin
     if par_value NOTNULL then
       UPDATE "Accounts" set first_name = par_value where user_id=2;
        loc_res = 'ok';
     else
       loc_res = 'Error';
     end if;
     return loc_res;
      end;
$$;

