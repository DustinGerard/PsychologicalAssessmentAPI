CREATE FUNCTION postanswer16(par_value text)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;
  begin
     if par_value NOTNULL then
       UPDATE depression set answer = par_value where dep_qstn=8;
       UPDATE depression set (points,correspondence) = (3,'Nearly every day') where answer = 'A' or answer = 'a';
       UPDATE depression set (points,correspondence) = (2,'More than half the days') where answer = 'B' or answer = 'b';
       UPDATE depression set (points,correspondence) = (1,'Several days') where answer = 'C' or answer = 'c';
       UPDATE depression set (points,correspondence) = (0,'Not at all') where answer = 'D' or answer = 'd';
        loc_res = 'ok';
     else
       loc_res = 'Error';
     end if;
     return loc_res;
      end;
$$;

