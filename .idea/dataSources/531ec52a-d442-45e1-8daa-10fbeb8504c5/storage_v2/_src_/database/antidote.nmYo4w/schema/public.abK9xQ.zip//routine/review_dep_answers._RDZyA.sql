CREATE FUNCTION review_dep_answers(OUT integer, OUT character varying, OUT text, OUT integer)
  RETURNS SETOF record
LANGUAGE SQL
AS $$
select dep_qstn, question, correspondence, points from depression
  ORDER BY dep_qstn ASC;
$$;

