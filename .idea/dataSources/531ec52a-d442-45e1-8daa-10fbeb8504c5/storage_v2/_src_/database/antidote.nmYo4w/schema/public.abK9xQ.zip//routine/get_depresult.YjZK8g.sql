CREATE FUNCTION get_depresult(OUT integer, OUT text)
  RETURNS SETOF record
LANGUAGE SQL
AS $$
select totalscore, diagnosis from results where category = 'Depression';
$$;

