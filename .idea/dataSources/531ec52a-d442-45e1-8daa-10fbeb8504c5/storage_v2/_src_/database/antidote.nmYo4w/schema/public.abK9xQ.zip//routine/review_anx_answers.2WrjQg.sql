CREATE FUNCTION review_anx_answers(OUT integer, OUT character varying, OUT text, OUT integer)
  RETURNS SETOF record
LANGUAGE SQL
AS $$
select anx_qstn, question, correspondence, points from anxiety
  ORDER BY anx_qstn ASC;
$$;

