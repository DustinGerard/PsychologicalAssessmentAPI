CREATE FUNCTION get_anxresult(OUT integer, OUT text)
  RETURNS SETOF record
LANGUAGE SQL
AS $$
select totalscore, diagnosis from results where category = 'Anxiety';
$$;

